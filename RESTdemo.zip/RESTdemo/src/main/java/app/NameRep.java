package app;

import org.springframework.data.jpa.repository.JpaRepository;

interface NameRepository extends JpaRepository<Name, Long> {

}