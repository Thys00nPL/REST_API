package app;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
class NameController {

    private final NameRepository repository;

    NameController(NameRepository repository) {
        this.repository = repository;
    }


    // Aggregate root
    // tag::get-aggregate-root[]
    @GetMapping("/hello")

    List<Name> all() {
        return repository.findAll();
    }
    // end::get-aggregate-root[]

    @PostMapping("/hello")
    Name newName(@RequestBody Name newName) {
        return repository.save(newName);
    }

    // Single item

    @GetMapping("/Names/{id}")
    Name one(@PathVariable Long id) {

        return repository.findById(id)
                .orElseThrow(() -> new NameNotFoundException(id));
    }

    @PutMapping("/Names/{id}")
    Name replaceName(@RequestBody Name newName, @PathVariable Long id) {

        return repository.findById(id)
                .map(employee -> {
                    employee.setName(newName.getName());
                    return repository.save(employee);
                })
                .orElseGet(() -> {
                    newName.setId(id);
                    return repository.save(newName);
                });
    }

    @DeleteMapping("/Names/{id}")
    void deleteEName(@PathVariable Long id) {
        repository.deleteById(id);
    }
}